export class Course {
  
    courseId: number = 0;
    name:String = '';
    duration:String = '';
    description:String = '';
}

